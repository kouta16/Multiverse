/* Multiverse WebSocket client. */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.Net = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var ws = null;
  var handlers = {};
  var queue = [];

  function wsUrl() {
    var proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
    return proto + location.host;
  }

  function connect(handlersIn) {
    handlers = handlersIn || {};
    queue = [];
    ws = new WebSocket(wsUrl());
    ws.onopen = function () {
      while (queue.length) {
        ws.send(JSON.stringify(queue.shift()));
      }
      if (handlers.onOpen) handlers.onOpen();
    };
    ws.onclose = function () { if (handlers.onClose) handlers.onClose(); };
    ws.onerror = function () { if (handlers.onError) handlers.onError(); };
    ws.onmessage = function (ev) {
      var msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (msg.t === 'state') {
        if (handlers.onState) handlers.onState(msg);
      } else if (msg.t === 'error') {
        if (handlers.onServerError) handlers.onServerError(msg.msg);
      } else if (msg.t === 'steal') {
        if (handlers.onSteal) handlers.onSteal(msg);
      } else if (msg.t === 'saveEvt') {
        if (handlers.onCardSave) handlers.onCardSave(msg);
      } else if (msg.t === 'swapEvt') {
        if (handlers.onCardSwap) handlers.onCardSwap(msg);
      } else if (msg.t === 'twoFaceEvt') {
        if (handlers.onTwoFaceEvt) handlers.onTwoFaceEvt(msg);
      } else if (msg.t === 'helaEvt') {
        if (handlers.onHelaEvt) handlers.onHelaEvt(msg);
      } else if (msg.t === 'kilgraveTargets') {
        if (handlers.onKilgraveTargets) handlers.onKilgraveTargets(msg);
      } else if (msg.t === 'kilgraveEvt') {
        if (handlers.onKilgraveEvt) handlers.onKilgraveEvt(msg);
      } else if (msg.t === 'riddlerEvt') {
        if (handlers.onRiddlerEvt) handlers.onRiddlerEvt(msg);
      } else if (msg.t === 'mrFreezeTargets') {
        if (handlers.onMrFreezeTargets) handlers.onMrFreezeTargets(msg);
      } else if (msg.t === 'mrFreezeEvt') {
        if (handlers.onMrFreezeEvt) handlers.onMrFreezeEvt(msg);
      } else if (msg.t === 'translucentEvt') {
        if (handlers.onTranslucentEvt) handlers.onTranslucentEvt(msg);
      } else if (msg.t === 'stats') {
        if (handlers.onStats) handlers.onStats(msg);
      } else if (msg.t === 'chat') {
        if (handlers.onChat) handlers.onChat(msg);
      } else if (msg.t === 'chatHistory') {
        if (handlers.onChatHistory) handlers.onChatHistory(msg);
      } else if (msg.t === 'pong') {
        if (handlers.onPong) handlers.onPong();
      }
    };
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
    else queue.push(obj);
  }

  function isOpen() { return ws && ws.readyState === WebSocket.OPEN; }

  function close() { if (ws) { try { ws.close(); } catch (e) {} } ws = null; }

  return { connect: connect, send: send, isOpen: isOpen, close: close };
});
